﻿/* Ana Mendes
 * anamendes23@gmail.com
 * github.com/anamendes23
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalReview_2_Ana
{
    public partial class Form1 : Form
    {
        //1. Define an abstract class, using your own words and provide a complete statement(for full credit)
        //       an abstract class has at least one abstract method that must be implemented by a child of the abstract class
        //       in the abstract class, the abstract methods cannot have a body.
        //2. What is the difference between an abstract class and an interface. Use your own words and 
        //provide complete statements(for full credit)
        //       Other classes inherit from an abstract class and implement an interface. Interfaces don't have fields
        //       or constructor, only properties and methods and they are all public and abstract. The child MUST implement
        //       ALL methods and propeties. An interface can't create an instance of an object.


        //-------------------------------GLOBAL VARIABLES----------------------------------------
        List<_2DShape> shapes = new List<_2DShape>();

        public Form1()
        {
            InitializeComponent();
            InitializeShapes();
        }

        //-------------------------------INITIALIZE SHAPES---------------------------------------
        public void InitializeShapes()
        {
            //create 3 squares
            Square s1 = new Square(0, 0, 30, 30, Color.Aquamarine);
            Square s2 = new Square(60, 60, 20, 20, Color.Red);
            Square s3 = new Square(100, 100, 10, 10, Color.Olive);
            shapes.Add(s1);
            shapes.Add(s2);
            shapes.Add(s3);
            //create 3 circles
            Circle c1 = new Circle(0, 200, 30, 30, Color.Navy);
            Circle c2 = new Circle(60, 180, 20, 20, Color.Orange);
            Circle c3 = new Circle(100, 160, 10, 10, Color.Green);
            shapes.Add(c1);
            shapes.Add(c2);
            shapes.Add(c3);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        //-------------------------------DISPLAY SHAES MEHOTD------------------------------------
        private void Display(List<_2DShape> shapes, PaintEventArgs e)
        {
            foreach (_2DShape s in shapes)
            {
                Bitmap bmap = s.Fill();
                Image image = (Image)bmap;
                e.Graphics.DrawImage(image, panel1.Location.X, panel1.Location.Y);
            }
        }
        //-------------------------------PAINT EVENT--------------------------------------------
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Display(shapes, e);
        }
    }
}
